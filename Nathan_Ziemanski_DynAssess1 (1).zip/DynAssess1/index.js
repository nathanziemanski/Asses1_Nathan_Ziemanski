document.getElementById("bg1").addEventListener("click", function(){
    document.getElementById("ch1").style.backgroundImage = "url(imgs/i1.jpg)";
 
});


document.getElementById("bg2").addEventListener("click", function(){
    document.getElementById("ch2").style.backgroundImage = "url(imgs/i4.jpg)";
 
});


document.getElementById("bg3").addEventListener("click", function(){
    document.getElementById("ch3").style.backgroundImage = "url(imgs/i5.jpg)";
 
});

