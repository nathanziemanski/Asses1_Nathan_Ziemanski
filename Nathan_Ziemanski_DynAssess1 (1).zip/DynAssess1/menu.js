document.getElementById("openbut").addEventListener("click", function(){
    
    document.getElementById("menu").style.left = "0px";
    
});


document.getElementById("closebut").addEventListener("click", function(){
    
    document.getElementById("menu").style.left = "-110px";
    
});
